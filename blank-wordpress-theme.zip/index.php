<?php
// Intentionally left blank for headless setup
